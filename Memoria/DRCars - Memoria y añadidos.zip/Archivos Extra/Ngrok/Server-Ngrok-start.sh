#!/bin/bash

LOG_FILE="/home/pancetas/ngrok_start.log"


log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> "$LOG_FILE"
}


TOKEN="***************************************"        
CHAT_ID="*********"                      

enviar_telegram() {
    local MENSAJE="$1"
    curl -s -X POST "https://api.telegram.org/bot${TOKEN}/sendMessage" \
        -d chat_id="${CHAT_ID}" \
        -d text="$MENSAJE" \
        -d parse_mode="Markdown"
}

echo "⏳ Iniciando túneles ngrok para API y SSH..."

nohup ngrok start --all >> /home/pancetas/bin/ngrok_all.log 2>&1 &

sleep 8

get_ngrok_url() {
    local nombre="$1"
    for i in {1..10}; do
        url=$(curl -s http://127.0.0.1:4040/api/tunnels | jq -r ".tunnels[] | select(.name == \"$nombre\") | .public_url")
        if [[ -n "$url" && "$url" != "null" ]]; then
            log "✅ URL obtenida para $nombre: $url"
            echo "$url"
            return
        fi
        sleep 1
    done
    log "⚠️ No se encontró URL para $nombre"
    echo "No disponible"
}

api_url=$(get_ngrok_url "api-drcars")
ssh_url=$(get_ngrok_url "ssh-remote")

mensaje="**🚀 Túneles Ngrok creados: **

 **API**: [$api_url]($api_url)

 **SSH**: [$ssh_url]($ssh_url)"

enviar_telegram "$mensaje"
log "Mensaje enviado por Telegram."