"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

// Modificar la interfaz UserData para incluir el campo dni
export interface UserData {
  id: string
  name: string
  email: string
  avatar?: string
  totalSpent: number
  joinedDate: string
  lastLogin: string
  favorites: number[]
  recentViews: number[]
  dni?: string // Añadir el campo dni como opcional
}

// Modificar la interfaz UserContextType para incluir un nuevo estado
interface UserContextType {
  user: UserData | null
  isLoading: boolean
  isAuthenticated: boolean
  login: (email: string, password: string, remember?: boolean, showNotification?: boolean) => Promise<boolean>
  logout: (showNotification?: boolean) => void
  updateUserData: (data: Partial<UserData>) => void
  getSavedCredentials: () => { email: string; password: string } | null
  lastAuthAction: "login" | "logout" | null
  // Añadir esta nueva función
  resetAuthAction: () => void
}

const UserContext = createContext<UserContextType | undefined>(undefined)

// Función para guardar credenciales en localStorage
const saveCredentials = (email: string, password: string, remember: boolean) => {
  if (remember) {
    localStorage.setItem("drcars-credentials", JSON.stringify({ email, password }))
  } else {
    localStorage.removeItem("drcars-credentials")
  }
}

// Función para obtener credenciales guardadas
const getSavedCredentials = () => {
  const saved = localStorage.getItem("drcars-credentials")
  if (saved) {
    return JSON.parse(saved)
  }
  return null
}

// Función para generar un avatar basado en las iniciales del email
const generateAvatar = (email: string) => {
  const name = email.split("@")[0]
  const initials = name.substring(0, 2).toUpperCase()
  return `/placeholder.svg?height=200&width=200&text=${initials}`
}

// Dummy function to satisfy the linter.  Replace with actual implementation.
const setupInactivityDetection = () => {
  console.warn("setupInactivityDetection is a placeholder function. Implement actual inactivity detection.")
}

export function UserProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserData | null>(null)
  const [isLoading, setIsLoading] = useState<boolean>(true)
  // Dentro de la función UserProvider, agregar el nuevo estado
  const [lastAuthAction, setLastAuthAction] = useState<"login" | "logout" | null>(null)

  // Comprobar si hay un usuario en localStorage al cargar
  useEffect(() => {
    const storedUserLocal = localStorage.getItem("drcars-user")
    const storedUserSession = sessionStorage.getItem("drcars-user")

    if (storedUserLocal) {
      setUser(JSON.parse(storedUserLocal))
    } else if (storedUserSession) {
      setUser(JSON.parse(storedUserSession))
    }

    setIsLoading(false)

    // Configurar detector de inactividad
    setupInactivityDetection()
  }, [])

  // Modificar la función login para incluir un DNI aleatorio
  const login = async (
    email: string,
    password: string,
    remember = false,
    showNotification = false, // Este parámetro no se usa actualmente, pero lo mantenemos por compatibilidad
  ): Promise<boolean> => {
    setIsLoading(true)

    // Simulación de login (aceptamos cualquier credencial)
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Generamos un nombre a partir del email
    const name = email
      .split("@")[0]
      .split(".")
      .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
      .join(" ")

    // Creamos un usuario con los datos proporcionados
    const userData: UserData = {
      id: `user_${Date.now()}`,
      name: name,
      email: email,
      avatar: generateAvatar(email),
      totalSpent: Math.floor(Math.random() * 200000),
      joinedDate: new Date().toISOString().split("T")[0],
      lastLogin: new Date().toISOString().split("T")[0],
      favorites: [1, 3, 8],
      recentViews: [2, 5, 7, 12],
      // No generamos un DNI aleatorio, el usuario lo proporcionará al solicitar una cita
    }

    setUser(userData)

    // Establecer la acción como login - Asegurarse de que esto se ejecuta
    setLastAuthAction("login")
    console.log("🟢 ACCIÓN: Login completado, lastAuthAction establecido a 'login'")
    // Nota: No mostramos ningún popup aquí, eso se manejará en los componentes específicos

    // Guardar en sessionStorage (se borra al cerrar la página) en lugar de localStorage
    // si no se marca "recordar"
    if (remember) {
      localStorage.setItem("drcars-user", JSON.stringify(userData))
      // Guardar credenciales si remember está activado
      saveCredentials(email, password, remember)
    } else {
      sessionStorage.setItem("drcars-user", JSON.stringify(userData))
      // Eliminar credenciales guardadas si existían
      localStorage.removeItem("drcars-credentials")
    }

    setIsLoading(false)
    return true
  }

  // Implementación de la función logout
  const logout = (showNotification?: boolean) => {
    setUser(null)
    localStorage.removeItem("drcars-user")
    sessionStorage.removeItem("drcars-user")
    setLastAuthAction("logout")
    console.log("🔴 ACCIÓN: Logout completado, lastAuthAction establecido a 'logout'")
    // Nota: No mostramos ningún popup aquí, eso se manejará en los componentes específicos
  }

  // Modificar la función updateUserData para asegurarnos de que maneja correctamente el DNI
  const updateUserData = (data: Partial<UserData>) => {
    if (user) {
      const updatedUser = { ...user, ...data }
      setUser(updatedUser)

      // Actualizar en localStorage o sessionStorage según corresponda
      if (localStorage.getItem("drcars-user")) {
        localStorage.setItem("drcars-user", JSON.stringify(updatedUser))
      } else if (sessionStorage.getItem("drcars-user")) {
        sessionStorage.setItem("drcars-user", JSON.stringify(updatedUser))
      }
    }
  }

  // Dentro de la función UserProvider, añadir la implementación de resetAuthAction
  const resetAuthAction = () => {
    console.log("🔄 Restableciendo lastAuthAction a null")
    setLastAuthAction(null)
  }

  // Incluir lastAuthAction en el value del Provider
  return (
    <UserContext.Provider
      value={{
        user,
        isLoading,
        isAuthenticated: !!user,
        login,
        logout,
        updateUserData,
        getSavedCredentials,
        lastAuthAction,
        resetAuthAction,
      }}
    >
      {children}
    </UserContext.Provider>
  )
}

export function useUser() {
  const context = useContext(UserContext)
  if (context === undefined) {
    throw new Error("useUser must be used within a UserProvider")
  }
  return context
}
